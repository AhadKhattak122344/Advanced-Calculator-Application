/*
Calculator v.1 Copyright (c) 2017 JJ Posti <techtimejourney.net> This program comes with ABSOLUTELY NO WARRANTY; 
for details see: http://www.gnu.org/copyleft/gpl.html. This is free software, and you are welcome to redistribute it under 
GPL Version 2, June 1991")
 */
package calculator;

/**
 *
 * @author JJ Posti - techtimejourney.net.
 */
public class Calculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Gui gui = new Gui();
    gui.setVisible(true);}
}
